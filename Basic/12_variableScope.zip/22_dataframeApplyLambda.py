import pandas as pd


df=pd.read_csv("policies.csv")
print(df)



highestCoverage=df["Coverage"].apply(lambda p:p>1000000)
print(highestCoverage)

df["discountedPremium"]=df["Premium"].apply(lambda p:p *0.90)
print(df)


newdf=list(
    df.apply(
        lambda p:
        {**p.to_dict(), 
        "discounted_amount":p["Premium"] * 0.90},
        axis=1
        )
    )
print(newdf)